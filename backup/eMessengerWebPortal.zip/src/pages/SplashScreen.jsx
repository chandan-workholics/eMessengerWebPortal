import React from 'react'


const SplashScreen = () => {
    return (
        <>
            <div className="container-fluid p-0 splash-screen-container">
            <img src={require("../Img/e-logo.png")} alt="logo-splash" className="" />
            </div>
        </>
    )
}

export default SplashScreen